[![Run in Postman](https://run.pstmn.io/button.svg)](https://app.getpostman.com/run-collection/6b293d0efca99692f79d#?env%5BBaden-W%C3%BCrttemberg%5D=W3sia2V5Ijoic3RhdGUiLCJ2YWx1ZSI6IkJhZGVuLVfDvHJ0dGVtYmVyZyIsImVuYWJsZWQiOnRydWV9XQ==)

# rkicasesapi

- Cloud Function zur Sammlung und Bereitstellung von COVID-19: Fallzahlen in Deutschland
- Jeden Tag um 12:00 (Europe/Berlin) werden Daten aus folgenden Quellen ausgelesen und persistiert: 
  - Fallzahlen vom [Robert Koch Institut](https://www.rki.de/DE/Content/InfAZ/N/Neuartiges_Coronavirus/Fallzahlen.html)
  - Genesene vom [esri](https://npgeo-corona-npgeo-de.hub.arcgis.com/search?groupIds=b28109b18022405bb965c602b13e1bbc)  
